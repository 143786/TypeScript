// // const person: {
//   name: string;
//   age: number;
// } = {
/*  here we are explicitly assigning the same TS inferred before. but 
that' not a good practice, but to understand object types,
 { name: string;
  age: number;
  }       This part is not object it's just helps TS understand the objects
          you're working with.

*/

/* this is the better syntax for learning and practice it so it's the implicit 
  assigning :
  */
const person = {
  name: "Ayline",
  age: 1,
};

console.log(person.age);

/* 
Nested Objects & Types :
Object types can also be created for nested objects.
let's say you have this JS object : 

const product = {
  id = 'abc1',
  price : 12.99,
  tags : ['great-offer' , 'hot-and-new'],
  details: {
    title : 'Red Carpet',
    description: ' A great carpet - almost brand-new!'

  }
}

This would be the type of such an object : 
{
id : string;
price : number;
tags : string[];
details : {
  title : string;
  description: string,
}

}

So you have an object type in an object type so to say.
*/
