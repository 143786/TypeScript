function add(n1: number, n2: number, showResult: boolean, phrase: string) {
  // if(typeof n1 !== 'number' || n2 !== 'number'){
  //  throw new Eror('Incorect input!');
  //  }
  const result = n1 + n2;
  if (showResult) {
    console.log(phrase + result);
  } else {
    return result;
  }
}
const number1 = 5;
const number2 = 2.8;
const printResult = true;
const resultPhrase = "Result is: ";

const result = add(number1, number2, printResult, resultPhrase);

/*  Type Assignment & Type Inference : it's a built-in feature of TS.
const number1 = 5;
const number2 = 2.8;

here we didn't write the type of the variables so TS know that they are 
number. so this is type reference.

The core task of TS is checking types and yelling at us if we're using them
incorrectly.

*/
