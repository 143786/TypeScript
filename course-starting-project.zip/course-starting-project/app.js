/* const person: {
  name : string;
  age : number;

} = {

*/
var person = {
    name: "Ayline",
    age: 1,
    hobbies: ["Sports", "Cooking"],
    role: [2, "author"],
};
person.role.push("admin");
// person.role[1] = 10;
var favoriteActivites;
// favoriteActivites = 'Sports';
/* this telle TS what we
 store in here is not just a single string, it's an array
 of string. if i try to store just sports in there, i get
 an error, because that is single string, and not an array
 of strings. i don't get an error, if i wrap this into
 squre brackets  and therefore effectively create
 an array :  */
favoriteActivites = ["Sports"];
/*
  if we put a number here in array, it's an array of strings
  and numbers, so that does not work and is not supported here.
  if we would want to support such as mixed array, one solution
  would be to use " any ". The 'any' type is a special type in
  TS, which we will have a closer look later, which basically
  means, do whatever you want. it's a type you don't wanna use
  too often. because you'll lose the benifits TS gives you,
  your back in JS world, where you also can use any value
  anywhere. so " any " is really flexible, but the flexibility
  comes at the price of giving up all benifits TS offer.
 */
console.log(person.name);
for (var _i = 0, _a = person.hobbies; _i < _a.length; _i++) {
    var hobby = _a[_i];
    console.log(hobby.toUpperCase());
}
/*                Working with Tuples :
TS holds as couple of new concepts, new types, which we don't know from vanilla JS
for example, the tuple type. Now you might know tuples from other programming
languages, JS does not have them. this is a tuple [1, 2] for example, and we would
say well this is an array. It is an array, It's an array, but it's a fixed length
array and not just fixed length but also fixed type. we will say that in person objec
above : role.

//// A tuple is a special constuct, TS understands, in JS it will be a normal array.
but during development with TS, we'll get errors.
This: role: [number, string]; tells TS I want to have s special array, with exactly
two elements,  the first element should be a number and the second element should be
a string. if we compile this code,



 */
