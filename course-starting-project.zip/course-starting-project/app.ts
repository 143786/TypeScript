/* const person: {
  name : string;
  age : number;

} = {

*/
const person: {
  name: string;
  age: number;
  hobbies: string[];
  role: [number, string];
} = {
  name: "Ayline",
  age: 1,
  hobbies: ["Sports", "Cooking"],
  role: [2, "author"],
};

//person.role.push("admin");
// person.role[1] = 10;
person.role = [0, "admin", 'user'];

let favoriteActivites: string[];
// favoriteActivites = 'Sports';
/* this telle TS what we
 store in here is not just a single string, it's an array
 of string. if i try to store just sports in there, i get
 an error, because that is single string, and not an array
 of strings. i don't get an error, if i wrap this into 
 squre brackets  and therefore effectively create
 an array :  */

favoriteActivites = ["Sports"];

/*   
  if we put a number here in array, it's an array of strings
  and numbers, so that does not work and is not supported here.
  if we would want to support such as mixed array, one solution
  would be to use " any ". The 'any' type is a special type in
  TS, which we will have a closer look later, which basically
  means, do whatever you want. it's a type you don't wanna use
  too often. because you'll lose the benifits TS gives you,
  your back in JS world, where you also can use any value 
  anywhere. so " any " is really flexible, but the flexibility
  comes at the price of giving up all benifits TS offer. 
 */
console.log(person.name);
for (const hobby of person.hobbies) {
  console.log(hobby.toUpperCase());
}

/*                Working with Tuples :
TS holds as couple of new concepts, new types, which we don't know from vanilla JS
for example, the tuple type. Now you might know tuples from other programming 
languages, JS does not have them. this is a tuple [1, 2] for example, and we would 
say well this is an array. It is an array, It's an array, but it's a fixed length 
array and not just fixed length but also fixed type. we will say that in person objec 
above : role.

//// A tuple is a special constuct, TS understands, in JS it will be a normal array.
but during development with TS, we'll get errors.
This: role: [number, string]; tells TS I want to have s special array, with exactly
two elements,  the first element should be a number and the second element should be 
a string. if we compile this code, 
. push is an exception which is allowed in tuple. so unfortunately TS can't catch
this error, but at least ensures that we're not assigning a wrong value here, and
outside of push, we also get some support regarding the length.
if we set person that tole to a new value. for example, an empty array is not allowed:
person.role = []; one with exaclty the structure we defined up there,
 person.role = [0, 'admin']; it's allowed if added an extra element here,
 person.role = [0, 'admin' 'user] then we would again get an error.  so the length 
 is enforced if we assign it like that, but not for a pushing and so on : 
 person.role.push("admin") ; This is something we have to be aware of, but still
 getting this support : person.role[1] = 10 and this person.role = [0, "admin", 'user'];
 support is pretty nice and if you have a scenario where you need exactly X amount of
 values in an array and you know the type of each vlaue in advance, then you might 
 want to consider a tuple instead of an array to get even more strictness into 
 you app to be enven clearer about the type of data you're working with and the 
 type of data you're expecting.



 */
